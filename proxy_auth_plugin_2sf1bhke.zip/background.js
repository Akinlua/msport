
        var config = {
                mode: "fixed_servers",
                rules: {
                  singleProxy: {
                    scheme: "http",
                    host: "brd.superproxy.io",
                    port: parseInt(33335)
                  },
                  bypassList: ["localhost"]
                }
              };
        chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
        function callbackFn(details) {
            return {
                authCredentials: {
                    username: "brd-customer-hl_1b6b5179-zone-datacenter_proxy1-ip-156.252.228.152",
                    password: "qh13e50d5n6f"
                }
            };
        }
        chrome.webRequest.onAuthRequired.addListener(
                callbackFn,
                {urls: ["<all_urls>"]},
                ['blocking']
        );
        